package com.onlinebanking;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Timestamp;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Properties;

import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.logging.LogEntry;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.SessionId;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.logging.LoggingPreferences;

import java.util.logging.Level;
import com.onlinebanking.ocr.CaptchaOCR;

public class Main {

    static {
        LogbackInitializer.init();
    }

    private static final Logger logger = AppLogger.getLogger(Main.class);

    // private static ChromeDriver driver;
    public static WebDriver driver;
    private static Properties config;
    private static DBHelper dbHelper;
    private static NetworkSpeedMonitor speedMonitor;
    
    // Step flow management
    private static final Step[] STEP_FLOW = Step.values();
    private static int currentStepIndex = 0;
    private static boolean flowFailed = false;

    enum Step {
        HOME_PAGE,
        // CLICK_LOGIN,
        LOGIN,
        // VIEW_ACCOUNTS,
        // TRANSFER_FUNDS,
        // OTP_CONFIRMATION,
        LOGOUT
    }

    public static void main(String[] args) {

        Timestamp overallStartTime = new Timestamp(System.currentTimeMillis());
        Timestamp overallEndTime = null;
        long responseTime = 0;
        String status = "SUCCESS";
        String errorLog = "";

        System.out.println("Starting the Synthetic Monitoring for CULE Portal...");

        try {
            loadConfig();

            String logsPath = config.getProperty("logs.path");
            if (logsPath == null || logsPath.isEmpty()) {
                throw new RuntimeException("logs.path is not set in config.properties");
            }
            File logDir = new File(logsPath);
            if (!logDir.exists()) {
                logDir.mkdirs();
            }

            System.setProperty("logs.path", logsPath);
            logger.info("Starting application...");

            // Initialize Database
            dbHelper = new DBHelper();
            dbHelper.connect();

            // Initialize Chrome Driver with logging capabilities
            logger.info("Setting WebDriver paths");

            // ///// Browser configuration
            // System.setProperty("webdriver.chrome.driver", config.getProperty("driver.path"));

            // // Enable browser logging to capture console errors
            // ChromeOptions options = new ChromeOptions();
            // LoggingPreferences logPrefs = new LoggingPreferences();
            // logPrefs.enable(LogType.BROWSER, Level.ALL);
            // logPrefs.enable(LogType.PERFORMANCE, Level.ALL);
            // options.setCapability("goog:loggingPrefs", logPrefs);
            
            // driver = new ChromeDriver(options);
            // DriverContext.driver = driver;

            driver = initializeDriver(config);
            DriverContext.driver = driver;

            RemoteWebDriver remoteDriver = (RemoteWebDriver) driver;
            String sessionId = remoteDriver.getSessionId().toString();
            Timestamp startTime = new Timestamp(System.currentTimeMillis());
            DriverContext.SESSION_ID = sessionId;

            System.out.println("Browser Session ID: " + sessionId);
            logger.info("Browser Session ID: " + sessionId);
            
            //Storing Session ID in database
            dbHelper.insertSessionInfo(sessionId, startTime);
            driver.manage().window().maximize();

            // ========== HOME PAGE LOAD WITH SPEED MONITORING ==========
            currentStepIndex = Step.HOME_PAGE.ordinal();
            
            if (!flowFailed) {
                Timestamp stepStart = new Timestamp(System.currentTimeMillis());
                int httpCode = -1;
                try {
                    String appUrl = config.getProperty("app.url");
                    httpCode = getHttpStatusCode(appUrl);

                    // Initialize Network Speed Monitor
                    speedMonitor = new NetworkSpeedMonitor();
                    speedMonitor.initialize(driver);
                    logger.info("Network Speed Monitor initialized");

                    // Log geolocation
                    logGeolocation(DriverContext.SESSION_ID);
                    logger.info("Scaling geolocation logging");

                    Point location = driver.manage().window().getPosition();
                    logger.info("Browser launched at screen position: X = " + location.getX() + ", Y = " + location.getY());

                    // Start speed monitoring BEFORE navigation
                    speedMonitor.startMonitoring();
                    
                    driver.get(appUrl);
                    // Thread.sleep(2000);
                
                    // Stop monitoring and get metrics
                    NetworkSpeedMonitor.NetworkMetrics metrics = speedMonitor.stopMonitoring();
                    
                    // Capture browser errors
                    String browserErrors = captureBrowserErrors();
                    
                    logger.info("Home page load successful");
                    logger.info("Status Code of application URL: {}", httpCode);
                    
                    metrics.display();
                    saveSpeedMetrics("Home Page", appUrl, metrics);
                    
                    // Log with browser errors if any
                    if (!browserErrors.isEmpty()) {
                        logger.warn("Browser errors detected on Home Page: {}", browserErrors);
                        logStep("Home Page", stepStart, "SUCCESS", "Page loaded with warnings: " + browserErrors, httpCode);
                    } else {
                        logStep("Home Page", stepStart, "SUCCESS", "", httpCode);
                    }
                    
                } catch (Exception e) {
                    flowFailed = true;
                    String browserErrors = captureBrowserErrors();
                    errorLog = buildErrorMessage("Error Loading Home Page", e, browserErrors);
                    logger.error(errorLog, e);
                    logStep("Home Page", stepStart, "FAILURE", errorLog, httpCode);
                    logRemainingStepsAsFailure(currentStepIndex + 1, "Skipped due to previous step failure");
                }
            }
            // ========== CLICK LOGIN BUTTON ==========
            currentStepIndex = Step.LOGIN.ordinal();
            
            if (!flowFailed) {
                Timestamp stepStart = new Timestamp(System.currentTimeMillis());
                int httpCode = -1;
                try {
                    String currentUrl = driver.getCurrentUrl();
                    httpCode = getHttpStatusCode(currentUrl);
                    
                //    driver.findElement(By.xpath("//*[@id=\"email\"]")).sendKeys("testlab.user@cohesity.com");
                //    Thread.sleep(1000);
                //    driver.findElement(By.xpath("testlab.user@cohesity.com"));

                driver.findElement(By.xpath("//*[@id=\"email\"]")).sendKeys(config.getProperty("user.email"));
                Thread.sleep(3000);
                driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div/div/div[2]/form/button")).click();
                    
                    String browserErrors = captureBrowserErrors();
                    // logger.info("Clicked on Login button");
                    
                    if (!browserErrors.isEmpty()) {
                        logger.warn("Browser errors after clicking login: {}", browserErrors);
                        logStep("Login", stepStart, "SUCCESS", "Action completed with warnings: " + browserErrors, httpCode);
                    } else {
                        logStep("Login", stepStart, "SUCCESS", "", httpCode);
                    }
                } catch (Exception e) {
                    flowFailed = true;
                    String browserErrors = captureBrowserErrors();
                    errorLog = buildErrorMessage("Error clicking login button", e, browserErrors);
                    logger.error(errorLog, e);
                    logStep("Login", stepStart, "FAILURE", errorLog, httpCode);
                    logRemainingStepsAsFailure(currentStepIndex + 1, "Skipped due to previous step failure");
                }
            }

            // ========== LOGIN WITH SPEED MONITORING ==========
            // currentStepIndex = Step.LOGIN.ordinal();

            //   driver.findElement(By.xpath("//*[@id=\"email\"]")).sendKeys("testlab.user@cohesity.com");
            //   Thread.sleep(3000);
            //   driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div/div/div[2]/form/button")).click();
                    
            
            // if (!flowFailed) {
            //     Timestamp stepStart = new Timestamp(System.currentTimeMillis());
            //     int httpCode = -1;
            //     logger.info("Logging into retail");
            //     int maxRetries = 2;
            //     int attempt = 0;
            //     boolean success = false;

            //     try {
            //         speedMonitor.startMonitoring();
            //         // Without Captcha automation
            //         // login();
            //         // Thread.sleep(1000);
                    
            //         // With Captcha automation
            //         while (attempt < maxRetries && !success) {
            //         try {
            //             attempt++;
            //             logger.info("Attempt {} of {}", attempt, maxRetries);

            //             // Step 2: Fill login form using XPath
            //             logger.info("Filling Login details...");

            //             WebElement phone = driver.findElement(By.xpath("//*[@id=\"phoneNumber\"]"));
            //             WebElement password = driver.findElement(By.xpath("//*[@id=\"password\"]"));
            //             WebElement loginBtn = driver.findElement(By.xpath("//*[@id=\"login-form\"]/button"));

            //             phone.sendKeys(config.getProperty("user.phone"));
            //             password.sendKeys(config.getProperty("user.password"));

            //             // Capture CAPTCHA image
            //             WebElement captchaImg = driver.findElement(By.xpath("//*[@id=\"captchaImg\"]"));
            //             File captchaFile = captchaImg.getScreenshotAs(OutputType.FILE);

            //             // OCR Processing
            //             CaptchaOCR ocr = new CaptchaOCR(ConfigLoader.get("tessdata.path"));
            //             String captchaText = ocr.readCaptcha(captchaFile);
                        
            //             logger.info("Extracted Captcha: ",captchaText);

            //             // Enter CAPTCHA and submit
            //             driver.findElement(By.xpath("//*[@id=\"captcha\"]")).sendKeys(captchaText);                      
            //             logger.info("Captch Entered Successfully...");
            //             logger.info("Waiting 10 secs for validation from user for the entered captcha...");
            //             // Thread.sleep(10000);

            //             // Now proceed with timing-sensitive step
            //             logger.info("Clicking Login...");
            //             loginBtn.click();

            //             // Wait for response to render
            //             Thread.sleep(2000);  // Giving time for message to appear

            //             // Check for CAPTCHA error message
            //             List<WebElement> errorDivs = driver.findElements(By.xpath("//div[@role='alert' and contains(@class, 'redbg')]"));
            //             boolean captchaFailed = false;

            //             for (WebElement errorDiv : errorDivs) {
            //                 String errorText = errorDiv.getText().trim();
            //                 if (errorText.contains("Entered verification Code does not match the Characters displayed in the picture.Please enter valid Captcha to proceed furthur.")) {
            //                     captchaFailed = true;
            //                     logger.warn("Captcha validation failed: {}", errorText);
            //                     break;
            //                 }
            //             }
                        
            //             if (captchaFailed) {
            //                 logger.info("Retrying due to captcha mismatch...");
            //             } else {
            //                 logger.info("Login successful.");
            //                 success = true;
            //             }
            //             }
            //             catch (Exception e) {
            //                 logger.error("Attempt {} failed due to exception: {}", attempt, e.getMessage());
                            
            //                 if (attempt < maxRetries) {
            //                     logger.info("Retrying...");
            //                     } else {
            //                             logger.error("All login attempts failed.");
            //                     }
            //             }
            //         }   
                    
            //         String currentUrl = driver.getCurrentUrl();
            //         httpCode = getHttpStatusCode(currentUrl);
                    
            //         NetworkSpeedMonitor.NetworkMetrics metrics = speedMonitor.stopMonitoring();
            //         metrics.display();
                    
            //         String browserErrors = captureBrowserErrors();
                    
            //         saveSpeedMetrics("Login", driver.getCurrentUrl(), metrics);
                    
            //         if (!browserErrors.isEmpty()) {
            //             logger.warn("Browser errors during login: {}", browserErrors);
            //             logStep("Login", stepStart, "SUCCESS", "Login completed with warnings: " + browserErrors, httpCode);
            //         } else {
            //             logStep("Login", stepStart, "SUCCESS", "", httpCode);
            //         }
                    
            //     } catch (Exception e) {
            //         flowFailed = true;
            //         String browserErrors = captureBrowserErrors();
            //         String currentUrl = driver.getCurrentUrl();
            //         httpCode = getHttpStatusCode(currentUrl);
            //         errorLog = buildErrorMessage("Login failed", e, browserErrors);
            //         logger.error(errorLog, e);
            //         logStep("Login", stepStart, "FAILURE", errorLog, httpCode);
            //         logRemainingStepsAsFailure(currentStepIndex + 1, "Skipped due to previous step failure");
            //     }
            // }

            // int maxRetries = 3;
            // int attempt = 0;
            // boolean success = false;
            // Exception lastException = null;

            // while (attempt < maxRetries && !success) {
            //     try {
            //         attempt++;
            //         logger.info("Attempt {} of {}", attempt, maxRetries);

            //         // Refresh for retry (skip on first attempt)
            //         if (attempt > 1) {
            //             driver.navigate().refresh();
            //             Thread.sleep(2000);
            //         }

            //         logger.info("Filling Login details...");

            //         WebElement phone = driver.findElement(By.xpath("//*[@id=\"phoneNumber\"]"));
            //         WebElement password = driver.findElement(By.xpath("//*[@id=\"password\"]"));
            //         WebElement loginBtn = driver.findElement(By.xpath("//*[@id=\"login-form\"]/button"));

            //         // Clear fields before reuse
            //         phone.clear();
            //         password.clear();

            //         phone.sendKeys(config.getProperty("user.phone"));
            //         password.sendKeys(config.getProperty("user.password"));

            //         // Capture CAPTCHA
            //         WebElement captchaImg = driver.findElement(By.xpath("//*[@id=\"captchaImg\"]"));
            //         File captchaFile = captchaImg.getScreenshotAs(OutputType.FILE);

            //         CaptchaOCR ocr = new CaptchaOCR(ConfigLoader.get("tessdata.path"));
            //         String captchaText = ocr.readCaptcha(captchaFile);

            //         logger.info("Extracted Captcha: {}", captchaText);

            //         WebElement captchaInput = driver.findElement(By.xpath("//*[@id=\"captcha\"]"));
            //         captchaInput.clear();
            //         captchaInput.sendKeys(captchaText);

            //         logger.info("Clicking Login...");
            //         loginBtn.click();

            //         Thread.sleep(2000);

            //         // Check CAPTCHA error
            //         List<WebElement> errorDivs = driver.findElements(
            //             By.xpath("//div[@role='alert' and contains(@class, 'redbg')]")
            //         );

            //         boolean captchaFailed = false;

            //         for (WebElement errorDiv : errorDivs) {
            //             String errorText = errorDiv.getText().trim();
            //             if (errorText.contains("Entered verification Code does not match")) {
            //                 captchaFailed = true;
            //                 break;
            //             }
            //         }

            //         if (captchaFailed) {
            //             if (attempt < maxRetries) {
            //                 logger.warn("Attempt {} failed due to CAPTCHA mismatch. Retrying...", attempt);
            //             }
            //         } else if (driver.getCurrentUrl().contains("dashboard")) {
            //             logger.info("Login successful.");
            //             success = true;
            //         } else {
            //             if (attempt < maxRetries) {
            //                 logger.warn("Attempt {} failed. Login not confirmed. Retrying...", attempt);
            //             }
            //         }

            //     } catch (Exception e) {
            //         lastException = e;

            //         if (attempt < maxRetries) {
            //             logger.warn("Attempt {} failed due to exception: {}", attempt, e.getMessage());
            //         }
            //     }
            // }

            // // Final failure logging ONLY after all retries exhausted
            // if (!success) {
            //     logger.error("All login attempts failed after {} retries.", maxRetries);

            //     if (lastException != null) {
            //         logger.error("Last exception: {}", lastException.getMessage(), lastException);
            //     }

            //     throw new RuntimeException("Login failed after retries", lastException);
            // }

//          if (!flowFailed) {
//     Timestamp stepStart = new Timestamp(System.currentTimeMillis());
//     int httpCode = -1;
//     logger.info("Logging into retail");

//     int maxRetries = 2;
//     int attempt = 0;
//     boolean success = false;
//     Exception lastException = null;
//     NetworkSpeedMonitor.NetworkMetrics metrics = null;  // ✅ Declared outside try
//     String browserErrors = "";                          // ✅ Declared outside try

//     speedMonitor.startMonitoring();  // ✅ Moved outside inner try so stopMonitoring() is always reachable

//     try {
//         while (attempt < maxRetries && !success) {
//             try {
//                 attempt++;
//                 logger.info("Attempt {} of {}", attempt, maxRetries);

//                 // Refresh only for retry attempts
//                 if (attempt > 1) {
//                     driver.navigate().refresh();
//                     Thread.sleep(2000);
//                 }

//                 logger.info("Filling Login details...");

//                 WebElement phone = driver.findElement(By.xpath("//*[@id=\"phoneNumber\"]"));
//                 WebElement password = driver.findElement(By.xpath("//*[@id=\"password\"]"));
//                 WebElement loginBtn = driver.findElement(By.xpath("//*[@id=\"login-form\"]/button"));

//                 // Clear fields before reuse
//                 phone.clear();
//                 password.clear();

//                 phone.sendKeys(config.getProperty("user.phone"));
//                 password.sendKeys(config.getProperty("user.password"));

//                 // Capture CAPTCHA
//                 WebElement captchaImg = driver.findElement(By.xpath("//*[@id=\"captchaImg\"]"));
//                 File captchaFile = captchaImg.getScreenshotAs(OutputType.FILE);

//                 CaptchaOCR ocr = new CaptchaOCR(ConfigLoader.get("tessdata.path"));
//                 String captchaText = ocr.readCaptcha(captchaFile);

//                 logger.info("Extracted Captcha: {}", captchaText);

//                 WebElement captchaInput = driver.findElement(By.xpath("//*[@id=\"captcha\"]"));
//                 captchaInput.clear();
//                 captchaInput.sendKeys(captchaText);

//                 logger.info("Clicking Login...");
//                 loginBtn.click();

//                 Thread.sleep(2000);

//                 // Check CAPTCHA error
//                 List<WebElement> errorDivs = driver.findElements(
//                         By.xpath("//div[@role='alert' and contains(@class, 'redbg')]")
//                 );

//                 boolean captchaFailed = false;

//                 for (WebElement errorDiv : errorDivs) {
//                     String errorText = errorDiv.getText().trim();
//                     if (errorText.contains("Entered verification Code does not match")) {
//                         captchaFailed = true;
//                         break;
//                     }
//                 }

//                 if (captchaFailed) {
//                     if (attempt < maxRetries) {
//                         logger.warn("Attempt {} failed due to CAPTCHA mismatch. Retrying...", attempt);
//                     }
//                 } else {
//                     boolean isLoggedIn = driver.findElements(By.id("logoutButton")).size() > 0;

//                     if (isLoggedIn) {
//                         logger.info("Login successful.");
//                         success = true;
//                     } else {
//                         if (attempt < maxRetries) {
//                             logger.warn("Attempt {} failed. Login not confirmed. Retrying...", attempt);
//                         }
//                     }
//                 }

//             } catch (Exception e) {
//                 lastException = e;
//                 if (attempt < maxRetries) {
//                     logger.warn("Attempt {} failed due to exception: {}", attempt, e.getMessage());
//                 }
//             }
//         }

//         // ===== Post Login Processing =====

//         String currentUrl = driver.getCurrentUrl();
//         httpCode = getHttpStatusCode(currentUrl);

//         metrics = speedMonitor.stopMonitoring();  // ✅ Always reached after loop
//         metrics.display();

//         browserErrors = captureBrowserErrors();
//         saveSpeedMetrics("Login", currentUrl, metrics);

//         if (success) {
//             if (!browserErrors.isEmpty()) {
//                 logger.warn("Browser errors during login: {}", browserErrors);
//                 logStep("Login", stepStart, "SUCCESS",
//                         "Login completed with warnings: " + browserErrors, httpCode);
//             } else {
//                 logStep("Login", stepStart, "SUCCESS", "", httpCode);
//             }
//         } else {
//             flowFailed = true;

//             String errorMsg = "Login failed after " + maxRetries + " attempts";
//             if (lastException != null) {
//                 errorMsg += " | Last exception: " + lastException.getMessage();
//             }

//             logger.error(errorMsg);
//             logStep("Login", stepStart, "FAILURE", errorMsg, httpCode);
//             logRemainingStepsAsFailure(currentStepIndex + 1,
//                     "Skipped due to previous step failure");
//         }

//     } catch (Exception e) {
//         flowFailed = true;

//         // ✅ Ensure monitor is stopped even on unexpected failure
//         if (metrics == null) {
//             try {
//                 metrics = speedMonitor.stopMonitoring();
//                 if (metrics != null) saveSpeedMetrics("Login", driver.getCurrentUrl(), metrics);
//             } catch (Exception ignored) {}
//         }

//         browserErrors = captureBrowserErrors();
//         String currentUrl = driver.getCurrentUrl();
//         httpCode = getHttpStatusCode(currentUrl);

//         String finalErrorLog = buildErrorMessage("Login failed", e, browserErrors);
//         logger.error(finalErrorLog, e);

//         // ✅ Single logStep call using finalErrorLog (removed duplicate with undefined `errorLog`)
//         logStep("Login", stepStart, "FAILURE", finalErrorLog, httpCode);
//         logRemainingStepsAsFailure(currentStepIndex + 1,
//                 "Skipped due to previous step failure");
//     }
// }

// if (!flowFailed) {
//     Timestamp stepStart = new Timestamp(System.currentTimeMillis());
//     int httpCode = -1;
//     logger.info("Logging into retail");
//     int maxRetries = 2;
//     int attempt = 0;
//     boolean success = false;
//     Exception lastException = null;

//     try {
//         speedMonitor.startMonitoring();

//         while (attempt < maxRetries && !success) {  // ← attempt < maxRetries is correct
//             attempt++;                               // ← but maxRetries must be set correctly
//             logger.info("Attempt {} of {}", attempt, maxRetries);

//             try {
//                 // ── Reset page state before every attempt ──────────────────
//                 // On attempt > 1 the page is already open, so navigate to login fresh
//                 if (attempt > 1) {
//                     logger.info("Refreshing page before retry attempt {}...", attempt);
//                     driver.navigate().refresh();
//                     Thread.sleep(1500);
//                 }

//                 // Fill login form
//                 logger.info("Filling Login details...");
//                 WebElement phone = driver.findElement(By.xpath("//*[@id=\"phoneNumber\"]"));
//                 // WebElement password = driver.findElement(By.xpath("//*[@id=\"password\"]"));
//                 WebElement loginBtn = driver.findElement(By.xpath("//*[@id=\"login-form\"]/button"));

//                 phone.clear();                                          // ← clear before sendKeys on retry
//                 phone.sendKeys(config.getProperty("user.phone"));
//                 // password.clear();                                       // ← clear before sendKeys on retry
//                 // password.sendKeys(config.getProperty("user.password"));

//             // Capture CAPTCHA image - Start
//                 WebElement captchaImg = driver.findElement(By.xpath("//*[@id=\"captchaImg\"]"));
//                 File captchaFile = captchaImg.getScreenshotAs(OutputType.FILE);

//                 // OCR Processing
//                 CaptchaOCR ocr = new CaptchaOCR(ConfigLoader.get("tessdata.path"));
//                 String captchaText = ocr.readCaptcha(captchaFile);
//                 logger.info("Extracted Captcha: {}", captchaText);     // ← fixed placeholder

//                 // Enter CAPTCHA
//                 WebElement captchaField = driver.findElement(By.xpath("//*[@id=\"captcha\"]"));
//                 captchaField.clear();                                   // ← clear captcha field too
//                 captchaField.sendKeys(captchaText);
//                 logger.info("Captcha Entered Successfully...");
//             //Captch identification Ends

        //     //     // Click login
        //     //     logger.info("Clicking Login...");
        //     //     loginBtn.click();

        //     //     // Wait for response to render
        //     //     Thread.sleep(2000);

        //     //     // Check for CAPTCHA error message
        //     //     List<WebElement> errorDivs = driver.findElements(
        //     //         By.xpath("//div[@role='alert' and contains(@class, 'redbg')]")
        //     //     );

        //     //     boolean captchaFailed = false;
        //     //     for (WebElement errorDiv : errorDivs) {
        //     //         String errorText = errorDiv.getText().trim();
        //     //         if (errorText.contains("Entered verification Code does not match")) {
        //     //             captchaFailed = true;
        //     //             logger.warn("Captcha mismatch on attempt {}/{}: {}", attempt, maxRetries, errorText);
        //     //             break;
        //     //         }
        //     //     }

        //     //     if (captchaFailed) {
        //     //         // ↓ Do NOT set success = true, loop will naturally retry
        //     //         if (attempt < maxRetries) {
        //     //             logger.info("Captcha failed, will retry... ({}/{})", attempt, maxRetries);
        //     //         } else {
        //     //             // Last attempt also failed — throw so outer catch handles it
        //     //             logger.error("Captcha failed on all {} attempts. Giving up.", maxRetries);
        //     //             throw new RuntimeException("Captcha validation failed after " + maxRetries + " attempts.");
        //     //         }

        //     //     } else {
        //     //         logger.info("Login successful on attempt {}.", attempt);
        //     //         success = true;   // ← exits the while loop cleanly
        //     //     }

        //     // } catch (RuntimeException re) {
        //     //     // Re-throw RuntimeException (our deliberate failure) to outer catch
        //     //     throw re;

        //     // } catch (Exception e) {
        //         lastException = e;
        //         logger.info("Attempt {}/{} hit an exception: {}", attempt, maxRetries, e.getMessage());

        //         if (attempt >= maxRetries) {
        //             // Last attempt — log and bubble up
        //             logger.error("All {} login attempts failed due to exception.", maxRetries);
        //             throw new RuntimeException("Login failed after " + maxRetries + " attempts: " + e.getMessage(), e);
        //         } else {
        //             logger.info("Will retry after exception...");
        //         }
        //     }
        // } // ── end while ──────────────────────────────────────────────────────

        // if (!success) {
        //     throw new RuntimeException("Login did not succeed after " + maxRetries + " attempts.");
        // }

//         // ── Success path ────────────────────────────────────────────────────
//         String currentUrl = driver.getCurrentUrl();
//         httpCode = getHttpStatusCode(currentUrl);

//         NetworkSpeedMonitor.NetworkMetrics metrics = speedMonitor.stopMonitoring();
//         metrics.display();

//         String browserErrors = captureBrowserErrors();
//         saveSpeedMetrics("Login", currentUrl, metrics);

//         if (!browserErrors.isEmpty()) {
//             logger.warn("Browser errors during login: {}", browserErrors);
//             logStep("Login", stepStart, "SUCCESS", "Login completed with warnings: " + browserErrors, httpCode);
//         } else {
//             logStep("Login", stepStart, "SUCCESS", "", httpCode);
//         }

//     } catch (Exception e) {
//         // ── Failure path — only reached after ALL retries exhausted ─────────
//         flowFailed = true;
//         String browserErrors = captureBrowserErrors();
//         String currentUrl = driver.getCurrentUrl();
//         httpCode = getHttpStatusCode(currentUrl);
//         errorLog = buildErrorMessage("Login failed", e, browserErrors);
//         logger.error(errorLog, e);
//         logStep("Login", stepStart, "FAILURE", errorLog, httpCode);
//         logRemainingStepsAsFailure(currentStepIndex + 1, "Skipped due to previous step failure");
//     }
// }
            // ========== VIEW ACCOUNTS WITH SPEED MONITORING ==========
            // currentStepIndex = Step.VIEW_ACCOUNTS.ordinal();
            
            // if (!flowFailed) {
            //     Timestamp stepStart = new Timestamp(System.currentTimeMillis());
            //     int httpCode = -1;
            //     try {
            //         speedMonitor.startMonitoring();
                    
            //         viewAccounts();
            //         // Thread.sleep(1000);
                    
            //         String currentUrl = driver.getCurrentUrl();
            //         httpCode = getHttpStatusCode(currentUrl);
                    
            //         NetworkSpeedMonitor.NetworkMetrics metrics = speedMonitor.stopMonitoring();
            //         metrics.display();
                    
            //         String browserErrors = captureBrowserErrors();
                    
            //         saveSpeedMetrics("View Accounts", driver.getCurrentUrl(), metrics);
                    
            //         if (!browserErrors.isEmpty()) {
            //             logger.warn("Browser errors during View Accounts: {}", browserErrors);
            //             logStep("View Accounts", stepStart, "SUCCESS", "Action completed with warnings: " + browserErrors, httpCode);
            //         } else {
            //             logStep("View Accounts", stepStart, "SUCCESS", "", httpCode);
            //         }
                    
            //     } catch (Exception e) {
            //         flowFailed = true;
            //         String browserErrors = captureBrowserErrors();
            //         String currentUrl = driver.getCurrentUrl();
            //         httpCode = getHttpStatusCode(currentUrl);
            //         errorLog = buildErrorMessage("View Accounts failed", e, browserErrors);
            //         logger.error(errorLog, e);
            //         logStep("View Accounts", stepStart, "FAILURE", errorLog, httpCode);
            //         logRemainingStepsAsFailure(currentStepIndex + 1, "Skipped due to previous step failure");
            //     }
            // }

            // // ========== TRANSFER FUNDS WITH SPEED MONITORING ==========
            // currentStepIndex = Step.TRANSFER_FUNDS.ordinal();
            
            // if (!flowFailed) {
            //     Timestamp stepStart = new Timestamp(System.currentTimeMillis());
            //     int httpCode = -1;
            //     try {
            //         speedMonitor.startMonitoring();
                    
            //         transferFunds();
            //         // Thread.sleep(1000);
                    
            //         String currentUrl = driver.getCurrentUrl();
            //         httpCode = getHttpStatusCode(currentUrl);
                    
            //         NetworkSpeedMonitor.NetworkMetrics metrics = speedMonitor.stopMonitoring();
            //         metrics.display();
                    
            //         String browserErrors = captureBrowserErrors();
                    
            //         saveSpeedMetrics("Transfer Funds", driver.getCurrentUrl(), metrics);
                    
            //         if (!browserErrors.isEmpty()) {
            //             logger.warn("Browser errors during Transfer Funds: {}", browserErrors);
            //             logStep("Transfer Funds", stepStart, "SUCCESS", "Action completed with warnings: " + browserErrors, httpCode);
            //         } else {
            //             logStep("Transfer Funds", stepStart, "SUCCESS", "", httpCode);
            //         }
                    
            //     } catch (Exception e) {
            //         flowFailed = true;
            //         String browserErrors = captureBrowserErrors();
            //         String currentUrl = driver.getCurrentUrl();
            //         httpCode = getHttpStatusCode(currentUrl);
            //         errorLog = buildErrorMessage("Transfer Funds failed", e, browserErrors);
            //         logger.error(errorLog, e);
            //         logStep("Transfer Funds", stepStart, "FAILURE", errorLog, httpCode);
            //         logRemainingStepsAsFailure(currentStepIndex + 1, "Skipped due to previous step failure");
            //     }
            // }

            // // ========== OTP CONFIRMATION WITH SPEED MONITORING ==========
            // currentStepIndex = Step.OTP_CONFIRMATION.ordinal();
            
            // if (!flowFailed) {
            //     Timestamp stepStart = new Timestamp(System.currentTimeMillis());
            //     int httpCode = -1;
            //     try {
            //         speedMonitor.startMonitoring();
                    
            //         enterOtpAndConfirm();
            //         // Thread.sleep(1000);
                    
            //         String currentUrl = driver.getCurrentUrl();
            //         httpCode = getHttpStatusCode(currentUrl);
                    
            //         NetworkSpeedMonitor.NetworkMetrics metrics = speedMonitor.stopMonitoring();
            //         metrics.display();
                    
            //         String browserErrors = captureBrowserErrors();
                    
            //         saveSpeedMetrics("OTP Confirmation", driver.getCurrentUrl(), metrics);
                    
            //         if (!browserErrors.isEmpty()) {
            //             logger.warn("Browser errors during OTP Confirmation: {}", browserErrors);
            //             logStep("OTP Confirmation", stepStart, "SUCCESS", "Action completed with warnings: " + browserErrors, httpCode);
            //         } else {
            //             logStep("OTP Confirmation", stepStart, "SUCCESS", "", httpCode);
            //         }
                    
            //     } catch (Exception e) {
            //         flowFailed = true;
            //         String browserErrors = captureBrowserErrors();
            //         String currentUrl = driver.getCurrentUrl();
            //         httpCode = getHttpStatusCode(currentUrl);
            //         errorLog = buildErrorMessage("OTP Confirmation failed", e, browserErrors);
            //         logger.error(errorLog, e);
            //         logStep("OTP Confirmation", stepStart, "FAILURE", errorLog, httpCode);
            //         logRemainingStepsAsFailure(currentStepIndex + 1, "Skipped due to previous step failure");
            //     }
            // }

            // ========== LOGOUT WITH SPEED MONITORING ==========
            currentStepIndex = Step.LOGOUT.ordinal();
            
            if (!flowFailed) {
                Timestamp stepStart = new Timestamp(System.currentTimeMillis());
                int httpCode = -1;
                try {
                    speedMonitor.startMonitoring();
                    
                    // goToDashboardAndLogout();

                    Thread.sleep(3000);

                    driver.findElement(By.id("radix-:r0:")).click();
                    Thread.sleep(500);
                    driver.findElement(By.id("radix-:r1:")).click();

                    // Thread.sleep(500);
                    
                    String currentUrl = driver.getCurrentUrl();
                    httpCode = getHttpStatusCode(currentUrl);
                    
                    NetworkSpeedMonitor.NetworkMetrics metrics = speedMonitor.stopMonitoring();
                    metrics.display();
                    
                    String browserErrors = captureBrowserErrors();
                    
                    saveSpeedMetrics("Logout", driver.getCurrentUrl(), metrics);
                    
                    if (!browserErrors.isEmpty()) {
                        logger.warn("Browser errors during Logout: {}", browserErrors);
                        logStep("Logout", stepStart, "SUCCESS", "Action completed with warnings: " + browserErrors, httpCode);
                    } else {
                        logStep("Logout", stepStart, "SUCCESS", "", httpCode);
                    }
                    
                } catch (Exception e) {
                    flowFailed = true;
                    String browserErrors = captureBrowserErrors();
                    String currentUrl = driver.getCurrentUrl();
                    httpCode = getHttpStatusCode(currentUrl);
                    errorLog = buildErrorMessage("Logout failed", e, browserErrors);
                    logger.error(errorLog, e);
                    logStep("Logout", stepStart, "FAILURE", errorLog, httpCode);
                    logRemainingStepsAsFailure(currentStepIndex + 1, "Skipped due to previous step failure");
                }
            }

            if (!flowFailed) {
                logger.info("Execution completed successfully.");
            } else {
                logger.warn("Execution completed with failures.");
                status = "FAILURE";
            }

        } catch (Exception e) {
            status = "FAILURE";
            errorLog = "Unexpected failure: " + truncateError(e.getMessage());
            logger.error("Unexpected error during execution", e);
        } finally {
            overallEndTime = new Timestamp(System.currentTimeMillis());
            responseTime = overallEndTime.getTime() - overallStartTime.getTime();

            try {
                logger.info("Final session status: {}", status);
                logger.info("Total execution time: {} ms", responseTime);

                if (dbHelper != null && DriverContext.SESSION_ID != null) {
                    dbHelper.finalizeSession(DriverContext.SESSION_ID, status);
                }

            } catch (Exception e) {
                logger.error("Failed to finalize session", e);
            }

            // Cleanup
            try {
                if (speedMonitor != null) speedMonitor.close();
                if (driver != null) driver.quit();
                if (dbHelper != null) dbHelper.close();
            } catch (Exception ignored) {}
        }
    }

    /**
     * Capture browser console errors and network errors
     */
    private static String captureBrowserErrors() {
        StringBuilder errors = new StringBuilder();
        try {
            // Capture browser console logs (JavaScript errors, warnings, etc.)
            LogEntries logEntries = driver.manage().logs().get(LogType.BROWSER);
            List<String> errorList = new ArrayList<>();
            
            for (LogEntry entry : logEntries) {
                Level level = entry.getLevel();
                // Capture SEVERE and WARNING level errors
                if (level == Level.SEVERE || level == Level.WARNING) {
                    String errorMsg = String.format("[%s] %s", level.getName(), entry.getMessage());
                    errorList.add(errorMsg);
                }
            }
            
            if (!errorList.isEmpty()) {
                errors.append("Browser Console Errors: ");
                errors.append(String.join(" | ", errorList));
            }
            
            // You can also capture performance logs for network errors
            try {
                LogEntries perfLogs = driver.manage().logs().get(LogType.PERFORMANCE);
                List<String> networkErrors = new ArrayList<>();
                
                for (LogEntry entry : perfLogs) {
                    String message = entry.getMessage();
                    // Look for failed network requests
                    if (message.contains("\"method\":\"Network.responseReceived\"") && 
                        (message.contains("\"status\":4") || message.contains("\"status\":5"))) {
                        networkErrors.add("Network error detected in performance logs");
                    }
                }
                
                if (!networkErrors.isEmpty() && errors.length() > 0) {
                    errors.append(" | ");
                }
                if (!networkErrors.isEmpty()) {
                    errors.append("Network Issues: ");
                    errors.append(String.join(" | ", networkErrors));
                }
            } catch (Exception e) {
                // Performance logs might not be available
                logger.debug("Could not capture performance logs: {}", e.getMessage());
            }
            
        } catch (Exception e) {
            logger.warn("Failed to capture browser errors: {}", e.getMessage());
        }
        
        return errors.toString();
    }

    /**
     * Build comprehensive error message including exception and browser errors
     */
    private static String buildErrorMessage(String context, Exception exception, String browserErrors) {
        StringBuilder errorMsg = new StringBuilder();
        errorMsg.append(context).append(": ");
        
        // Add exception details
        if (exception != null) {
            errorMsg.append("Exception: ").append(exception.getClass().getSimpleName()).append(" - ");
            
            // Clean the exception message - remove Selenium documentation links and build info
            String cleanMessage = cleanExceptionMessage(exception.getMessage());
            errorMsg.append(truncateError(cleanMessage));
            
            // Add root cause if available
            Throwable cause = exception.getCause();
            if (cause != null) {
                String cleanCauseMessage = cleanExceptionMessage(cause.getMessage());
                errorMsg.append(" | Root Cause: ").append(cause.getClass().getSimpleName());
                errorMsg.append(" - ").append(truncateError(cleanCauseMessage));
            }
        }
        
        // Add browser errors if any
        if (browserErrors != null && !browserErrors.isEmpty()) {
            errorMsg.append(" | ").append(browserErrors);
        }
        
        return errorMsg.toString();
    }

    /**
     * Clean exception message by removing Selenium documentation links and build info
     */
    private static String cleanExceptionMessage(String message) {
        if (message == null || message.isEmpty()) {
            return "";
        }
        
        // Split by newline and take only the first meaningful line
        String[] lines = message.split("\\r?\\n");
        StringBuilder cleanMsg = new StringBuilder();
        
        for (String line : lines) {
            line = line.trim();
            
            // Skip lines containing documentation links, build info, system info, driver info
            if (line.contains("For documentation on this error") ||
                line.contains("https://www.selenium.dev/") ||
                line.contains("Build info:") ||
                line.contains("System info:") ||
                line.contains("Driver info:") ||
                line.contains("Command duration") ||
                line.contains("Capabilities") ||
                line.contains("Session ID:") ||
                line.isEmpty()) {
                continue;
            }
            
            // Add meaningful lines
            if (cleanMsg.length() > 0) {
                cleanMsg.append(" ");
            }
            cleanMsg.append(line);
        }
        
        return cleanMsg.toString();
    }

    /**
     * Log all remaining steps as FAILURE when a previous step fails
     */
    private static void logRemainingStepsAsFailure(int startIndex, String reason) {
        for (int i = startIndex; i < STEP_FLOW.length; i++) {
            Step step = STEP_FLOW[i];
            logStep(
                step.name().replace("_", " "),
                new Timestamp(System.currentTimeMillis()),
                "FAILURE",
                reason,
                -1
            );
            logger.warn("Step {} marked FAILURE (not executed)", step);
        }
    }

    /**
     * Save network speed metrics to database
     */
    private static void saveSpeedMetrics(String testName, String url, NetworkSpeedMonitor.NetworkMetrics metrics) {
        try {
            dbHelper.insertNetworkSpeed(DriverContext.SESSION_ID,
                testName,
                url,
                metrics.downloadSpeedMbps,
                metrics.uploadSpeedMbps,
                metrics.downloadSpeedMBps,
                metrics.uploadSpeedMBps,
                metrics.totalBytesReceived,
                metrics.totalBytesSent,
                metrics.totalRequests,
                metrics.durationSeconds,
                metrics.avgRequestTimeMs,
                metrics.pageLoadTimeMs
            );
            logger.info("Network speed metrics saved for: {}", testName);
        } catch (Exception e) {
            logger.error("Failed to save network speed metrics for {}: {}", testName, e.getMessage(), e);
        }
    }

    private static void loadConfig() throws IOException {
        config = new Properties();
        FileInputStream fis = new FileInputStream("conf/config.properties");
        config.load(fis);
    }

    // Without Captcha automation
    // private static void login() throws InterruptedException {
    //     WebElement phone = driver.findElement(By.xpath("//*[@id=\"phoneNumber\"]"));
    //     WebElement password = driver.findElement(By.xpath("//*[@id=\"password\"]"));
    //     WebElement loginBtn = driver.findElement(By.xpath("//*[@id=\"login-form\"]/button"));

    //     phone.sendKeys(config.getProperty("user.phone"));
    //     password.sendKeys(config.getProperty("user.password"));

    //     logger.info("Current URL (Before Clicking Login Button): {}", driver.getCurrentUrl());
    //     loginBtn.click();
    //     Thread.sleep(5000);
    //     logger.info("Logged in successfully...");
    //     logger.info("Current URL (After Clicking Login Button): {}", driver.getCurrentUrl());
    // }

    private static void viewAccounts() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        logger.info("Current URL (Before Clicking View Accounts Button): {}", driver.getCurrentUrl());

        WebElement viewAccountsBtn = driver.findElement(By.xpath("/html/body/main/div/div[2]/div[3]/div/a"));
        viewAccountsBtn.click();
        Thread.sleep(1000);

        logger.info("Current URL (After Clicking View Accounts Button): {}", driver.getCurrentUrl());

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/main/div/div[1]/div/div/a")));
        WebElement backToDashboardBtn = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/main/div/div[1]/div/div/a")));

        backToDashboardBtn.click();
        logger.info("Clicked on Back to Dashboard button...");
    }

    private static void transferFunds() throws InterruptedException {
        driver.findElement(By.xpath("/html/body/main/div/div[2]/div[2]/div/a")).click();
        Thread.sleep(1000);

        WebElement Form_ac = driver.findElement(By.xpath("/html/body/main/div/div[2]/div/div/form/div[1]/div/select"));
        logger.info("Element: ", Form_ac);
        Select fromAccount = new Select(driver.findElement(By.id("fromAccount")));
        fromAccount.selectByIndex(1);
        Thread.sleep(1000);
        logger.info("Selected FROM account.");
        
        Select toAccount = new Select(driver.findElement(By.id("toAccount")));
        toAccount.selectByIndex(2);
        Thread.sleep(1000);
        logger.info("Selected TO account.");

        WebElement impsRadio = driver.findElement(By.xpath("//*[@id=\"imps\"]"));
        impsRadio.click();
        Thread.sleep(1000);
        logger.info("Selected transfer type as IMPS.");

        WebElement amountField = driver.findElement(By.xpath("//*[@id=\"amount\"]"));
        amountField.sendKeys("1");
        Thread.sleep(1000);
        logger.info("Added amount to transfer.");

        WebElement verifyBtn = driver.findElement(By.xpath("//*[@id=\"transfer-form\"]/button")); //Actual
        // WebElement verifyBtn = driver.findElement(By.id("transfer-form")); //False 
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", verifyBtn);
        Thread.sleep(1000);
        verifyBtn.click();
        Thread.sleep(1000);
        logger.info("Clicked on Verify & Complete Transfer button.");
    }

    private static void enterOtpAndConfirm() throws InterruptedException {
        String otp = getOtpFromPage();
        Thread.sleep(1000);
        logger.info("Get OTP Function Started...");

        WebElement otpInput = driver.findElement(By.xpath("//*[@id=\"otp\"]"));
        otpInput.sendKeys(otp);
        Thread.sleep(1000);

        WebElement confirmBtn = driver.findElement(By.xpath("//*[@id=\"confirm-form\"]/button"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", confirmBtn);
        Thread.sleep(1000);
        confirmBtn.click();
        logger.info("Clicked on Verify & Complete Transfer Button");
    }

    private static void goToDashboardAndLogout() throws InterruptedException {
        WebElement dashboardBtn = driver.findElement(By.xpath("/html/body/main/div/div/div/div/div[3]/a[1]"));
        dashboardBtn.click();
        Thread.sleep(1000);
        logger.info("Clicked on Go to Dashboard Button");

        WebElement logoutBtn = driver.findElement(By.xpath("//*[@id=\"navbarNav\"]/ul/a"));
        // WebElement logoutBtn = driver.findElement(By.xpath("//*[@id=\"navbarNav\"]/ul/b"));
        logoutBtn.click();
        Thread.sleep(1000);
        logger.info("Clicked on Logout Button");
    }

    private static String getOtpFromPage() throws InterruptedException{
        Thread.sleep(1000);
        WebElement otpElement = driver.findElement(By.xpath("//*[@id=\"otp-display\"]"));
        String fullText = otpElement.getText();
        String otp = fullText.replaceAll("\\D+", "");
        logger.info("OTP extracted: {}", otp);
        return otp;
    }

    private static void logStep(String stepName, Timestamp startTime, String status, String errorLog, int responseCode) {
        Timestamp endTime = new Timestamp(System.currentTimeMillis());
        long responseTime = endTime.getTime() - startTime.getTime();

        if ("FAILURE".equalsIgnoreCase(status)) {
            captureSnapshot(stepName);
        }

        try {
            dbHelper.insertLog(DriverContext.SESSION_ID, stepName, startTime, endTime, responseTime, status, errorLog, responseCode);
        } catch (Exception e) {
            logger.error("Failed to insert log for step '" + stepName + "': " + truncateError(e.getMessage()), e);
        }
    }

    private static String truncateError(String message) {
        if (message == null) return "";
        return message.length() > 500 ? message.substring(0, 500) + "..." : message;
    }

    private static void captureSnapshot(String stepName) {
        try {
            String snapshotDirPath = "snapshots";
            File snapshotDir = new File(snapshotDirPath);
            if (!snapshotDir.exists()) {
                snapshotDir.mkdirs();
            }

            String timestamp = String.valueOf(System.currentTimeMillis());
            String fileName = stepName.replaceAll("\\s+", "_") + "_" + timestamp + ".png";
            File destFile = new File(snapshotDirPath + File.separator + fileName);

            File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            FileHandler.copy(screenshot, destFile);

            logger.info("Snapshot captured for step '{}', saved at: {}", stepName, destFile.getAbsolutePath());
        } catch (Exception e) {
            logger.error("Failed to capture snapshot for step '{}': {}", stepName, e.getMessage(), e);
        }
    }

    private static void logGeolocation(String sessionId) {
        try {
            String apiURL = "http://ip-api.com/json";
            HttpURLConnection connection = (HttpURLConnection) new URL(apiURL).openConnection();
            connection.setRequestMethod("GET");

            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder response = new StringBuilder();
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            JSONObject geoData = new JSONObject(response.toString());

            logger.info("Geolocation Info:");
            String ip_address = geoData.getString("query");
            logger.info("IP Address: " + ip_address);
            String city = geoData.getString("city");
            logger.info("City: " + city);
            String region = geoData.getString("regionName");
            logger.info("Region: " + region);
            String country = geoData.getString("country");
            logger.info("Country: " + country);
            String isp = geoData.getString("isp");
            logger.info("ISP: " + isp);
            String timezone = geoData.getString("timezone");
            logger.info("Timezone: " + timezone);
            double longitude = geoData.getDouble("lon");
            logger.info("Longitude: " + longitude);
            double latitude = geoData.getDouble("lat");
            logger.info("Latitude: " + latitude);
            String browser = config.getProperty("driver.name");
            logger.info("Browser: " + browser);
            
            dbHelper.insertGeoLocation(sessionId, ip_address, city, region, country, isp, timezone, latitude, longitude, browser);

        } catch (Exception e) {
            logger.warn("Failed to fetch geolocation: " + e.getMessage());
        }
    }

    private static int getHttpStatusCode(String urlString) {
        try {
            URL url = new URL(urlString);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(5000);
            connection.connect();
            int responseCode = connection.getResponseCode();
            logger.debug("HTTP Status Code for {}: {}", urlString, responseCode);
            return responseCode;
        } catch (IOException e) {
            logger.warn("Failed to get HTTP status for URL: " + urlString + " - " + e.getMessage());
            return -1;
        }
    }

    private static WebDriver initializeDriver(Properties config) {

        String browser = config.getProperty("driver.name").trim();

        LoggingPreferences logPrefs = new LoggingPreferences();
        logPrefs.enable(LogType.BROWSER, Level.ALL);
        logPrefs.enable(LogType.PERFORMANCE, Level.ALL);

        switch (browser.toLowerCase()) {

            case "chrome":
                System.setProperty("webdriver.chrome.driver", config.getProperty("driver.path"));

                ChromeOptions chromeOptions = new ChromeOptions();
                chromeOptions.setCapability("goog:loggingPrefs", logPrefs);

                return new ChromeDriver(chromeOptions);

            case "edge":
                System.setProperty("webdriver.edge.driver", config.getProperty("driver.path"));

                EdgeOptions edgeOptions = new EdgeOptions();
                edgeOptions.setCapability("goog:loggingPrefs", logPrefs);

                return new EdgeDriver(edgeOptions);

            default:
                throw new IllegalArgumentException("Unsupported browser: " + browser);
        }
    }
}