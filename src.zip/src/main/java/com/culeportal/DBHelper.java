package com.culeportal;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.*;
import java.util.Properties;

public class DBHelper {

    private Connection connection;

    private String dbName;
    private String dbUrlWithoutDatabase;
    private String dbUrlWithDatabase;
    private String dbUser;
    private String dbPassword;
    private String tableName;

    // ================= CONNECT =================
    public void connect() {
        try {
            Properties props = new Properties();
            props.load(new FileInputStream("conf/config.properties"));

            dbName = props.getProperty("db.name");
            System.out.println("DB" + dbName);
            dbUrlWithoutDatabase = props.getProperty("db.connection.url");
            dbUser = props.getProperty("db.uname");
            dbPassword = props.getProperty("db.password");
            tableName = props.getProperty("db.table.name");

            dbUrlWithDatabase = dbUrlWithoutDatabase + "/" + dbName;

            System.out.println("🔌 Connecting to MySQL...");

            try (Connection tempConn =
                    DriverManager.getConnection(dbUrlWithoutDatabase, dbUser, dbPassword)) {
                createDatabaseIfNotExists(tempConn);
            }

            connection = DriverManager.getConnection(dbUrlWithDatabase, dbUser, dbPassword);
            System.out.println("✅ Connected to database: " + dbName);

            createSessionInfoTableIfNotExists();
            createSyntheticLogTableIfNotExists();
            createGeoTableIfNotExists();
            createNetworkSpeedTableIfNotExists();

        } catch (IOException | SQLException e) {
            System.err.println("❌ DB connection failed");
            e.printStackTrace();
        }
    }

    // ================= DATABASE =================
    private void createDatabaseIfNotExists(Connection conn) throws SQLException {
        try (Statement stmt = conn.createStatement()) {
            stmt.executeUpdate("CREATE DATABASE IF NOT EXISTS `" + dbName + "`");
        }
    }

    // ================= SYNTHETIC SESSION INFO TABLE =================
    private void createSessionInfoTableIfNotExists() {

    String sql =
            "CREATE TABLE IF NOT EXISTS session_info ("
        + " session_id VARCHAR(255) NOT NULL,"
        + " start_time TIMESTAMP NOT NULL,"
        + " end_time TIMESTAMP NULL,"
        + " status VARCHAR(20) NOT NULL DEFAULT 'IN_PROGRESS',"
        + " PRIMARY KEY (session_id)"
        + ")";

        executeDDL(sql, "Session Info table");
    }

    // ================= SYNTHETIC LOG TABLE =================
    private void createSyntheticLogTableIfNotExists() {
        String sql =
            "CREATE TABLE IF NOT EXISTS `" + tableName + "` (" +
            "id INT AUTO_INCREMENT PRIMARY KEY," +
            "session_id VARCHAR(255) NOT NULL," +
            "name VARCHAR(255)," +
            "start_time TIMESTAMP," +
            "end_time TIMESTAMP," +
            "response_time BIGINT," +
            "status VARCHAR(50)," +
            "error_log VARCHAR(10000)," +
            "response_code INT," +
            "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP," +
            "FOREIGN KEY (session_id) REFERENCES session_info(session_id)"+
            ")";
        executeDDL(sql, "Synthetic log table");
    }

    // ================= GEOLOCATION TABLE =================
    private void createGeoTableIfNotExists() {
        String sql =
            "CREATE TABLE IF NOT EXISTS geolocation_info (" +
            "id INT AUTO_INCREMENT PRIMARY KEY," +
            "session_id VARCHAR(255) NOT NULL," +
            "ip_address VARCHAR(45)," +
            "city VARCHAR(100)," +
            "region VARCHAR(100)," +
            "country VARCHAR(100)," +
            "isp VARCHAR(150)," +
            "timezone VARCHAR(50)," +
            "latitude DECIMAL(10,7)," +
            "longitude DECIMAL(10,7)," +
            "browser VARCHAR(50)," +
            "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP," +
            "FOREIGN KEY (session_id) REFERENCES session_info(session_id)"+
            ")";
        executeDDL(sql, "Geolocation table");
    }

    // ================= NETWORK SPEED TABLE =================
    private void createNetworkSpeedTableIfNotExists() {
        String sql =
            "CREATE TABLE IF NOT EXISTS network_speed_metrics (" +
            "id INT AUTO_INCREMENT PRIMARY KEY," +
            "session_id VARCHAR(255) NOT NULL," +
            "name VARCHAR(255)," +
            "url VARCHAR(500)," +
            "download_speed_mbps DECIMAL(10,2)," +
            "upload_speed_mbps DECIMAL(10,2)," +
            "download_speed_MB DECIMAL(10,2)," +
            "upload_speed_MB DECIMAL(10,2)," +
            "total_bytes_received BIGINT," +
            "total_bytes_sent BIGINT," +
            "total_requests INT," +
            "duration_seconds DECIMAL(10,3)," +
            "avg_request_time_ms DECIMAL(10,2)," +
            "page_load_time_ms BIGINT," +
            "test_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP," +
            "FOREIGN KEY (session_id) REFERENCES session_info(session_id)"+
            ")";
        executeDDL(sql, "Network speed table");
    }

    // ================= UPDATING THE SESSION INFO TABLE =================
    public void finalizeSession(String sessionId, String status) {
        String sql =
            "UPDATE session_info " +
            "SET status = ?, end_time = CURRENT_TIMESTAMP " +
            "WHERE session_id = ?";

        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setString(2, sessionId);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    ////////////////////////// Insert Statements////////////////////////////
    // ================= INSERT SYNTHETIC SESSION INFO LOG =================
    public void insertSessionInfo(String sessionId, Timestamp startTime) {

        String sql =
            "INSERT INTO session_info (session_id, start_time, status) " +
            "VALUES (?, ?, 'IN_PROGRESS') " +
            "ON DUPLICATE KEY UPDATE session_id = session_id";

        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, sessionId);
            ps.setTimestamp(2, startTime);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    // ================= INSERT SYNTHETIC LOG =================
    public void insertLog(String sessionId,
                          String name,
                          Timestamp startTime,
                          Timestamp endTime,
                          long responseTime,
                          String status,
                          String errorLog,
                          int responseCode) {

        String sql =
            "INSERT INTO `" + tableName + "` " +
            "(session_id, name, start_time, end_time, response_time, status, error_log, response_code) " +
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, sessionId);
            ps.setString(2, name);
            ps.setTimestamp(3, startTime);
            ps.setTimestamp(4, endTime);
            ps.setLong(5, responseTime);
            ps.setString(6, status);
            ps.setString(7, errorLog);
            ps.setInt(8, responseCode);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ================= INSERT GEOLOCATION =================
    public void insertGeoLocation(String sessionId,
                                  String ipAddress,
                                  String city,
                                  String region,
                                  String country,
                                  String isp,
                                  String timezone,
                                  double latitude,
                                  double longitude,
                                  String browser) {

        String sql =
            "INSERT INTO geolocation_info " +
            "(session_id, ip_address, city, region, country, isp, timezone, latitude, longitude, browser) " +
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, sessionId);
            ps.setString(2, ipAddress);
            ps.setString(3, city);
            ps.setString(4, region);
            ps.setString(5, country);
            ps.setString(6, isp);
            ps.setString(7, timezone);
            ps.setDouble(8, latitude);
            ps.setDouble(9, longitude);
            ps.setString(10, browser);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ================= INSERT NETWORK SPEED =================
    public void insertNetworkSpeed(String sessionId,
                                   String name,
                                   String url,
                                   double downloadSpeedMbps,
                                   double uploadSpeedMbps,
                                   double downloadSpeedMBps,
                                   double uploadSpeedMBps,
                                   long totalBytesReceived,
                                   long totalBytesSent,
                                   int totalRequests,
                                   double durationSeconds,
                                   double avgRequestTimeMs,
                                   long pageLoadTimeMs) {

        String sql =
            "INSERT INTO network_speed_metrics " +
            "(session_id, name, url, download_speed_mbps, upload_speed_mbps, " +
            "download_speed_MB, upload_speed_MB, total_bytes_received, " +
            "total_bytes_sent, total_requests, duration_seconds, " +
            "avg_request_time_ms, page_load_time_ms) " +
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, sessionId);
            ps.setString(2, name);
            ps.setString(3, url);
            ps.setDouble(4, downloadSpeedMbps);
            ps.setDouble(5, uploadSpeedMbps);
            ps.setDouble(6, downloadSpeedMBps);
            ps.setDouble(7, uploadSpeedMBps);
            ps.setLong(8, totalBytesReceived);
            ps.setLong(9, totalBytesSent);
            ps.setInt(10, totalRequests);
            ps.setDouble(11, durationSeconds);
            ps.setDouble(12, avgRequestTimeMs);
            ps.setLong(13, pageLoadTimeMs);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ================= UTIL =================
    private void executeDDL(String sql, String name) {
        try (Statement stmt = connection.createStatement()) {
            stmt.execute(sql);
            System.out.println("✅ " + name + " ready");
        } catch (SQLException e) {
            System.err.println("❌ Failed to create " + name);
            e.printStackTrace();
        }
    }

    // ================= CLOSE =================
    public void close() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
