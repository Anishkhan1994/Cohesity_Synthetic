package com.culeportal;

import java.io.FileWriter;
import java.io.PrintWriter;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Timestamp;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import java.util.Properties;

import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.logging.LogEntry;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.remote.RemoteWebDriver;

import org.slf4j.Logger;
import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.logging.LoggingPreferences;

import java.util.logging.Level;

public class Main {

    private static final String CSV_FOLDER = "errorlogs";
    private static final String CSV_FILE = CSV_FOLDER + File.separator + "ErrorLogs.csv";

    private static void initializeCSV() {

        try {

            File folder = new File(CSV_FOLDER);

            if (!folder.exists()) {
                folder.mkdirs();
            }

            File file = new File(CSV_FILE);

            if (!file.exists()) {

                PrintWriter pw = new PrintWriter(
                        new FileWriter(file));

                pw.println(
                        "Timestamp," +
                                "SessionID," +
                                "StepName," +
                                "ErrorType," +
                                "ErrorMessage," +
                                "CurrentURL," +
                                "BrowserErrors," +
                                "ScreenshotPath");

                pw.close();
            }

        } catch (Exception e) {

            logger.error("CSV initialization failed", e);
        }
    }

    // ===============================================================

    static {

        LogbackInitializer.init();
    }

    private static final Logger logger = AppLogger.getLogger(Main.class);

    // private static ChromeDriver driver;
    public static WebDriver driver;
    private static Properties config;
    private static DBHelper dbHelper;
    private static NetworkSpeedMonitor speedMonitor;

    // Step flow management
    private static final Step[] STEP_FLOW = Step.values();
    private static int currentStepIndex = 0;
    private static boolean flowFailed = false;

    enum Step {
        HOME_PAGE,
        LOGIN,
        DASHBOARD,
        TEMPLETE,
        DEPLOY_JOURNEY,
        INSTANCE_VIEW,
        CONSOLE,
        // LOGOUT
    }

    public static void main(String[] args) {

        Timestamp overallStartTime = new Timestamp(System.currentTimeMillis());
        Timestamp overallEndTime = null;
        long responseTime = 0;
        String status = "SUCCESS";
        String errorLog = "";

        logger.info("Starting the Synthetic Monitoring for CULE Portal...");

        try {
            initializeCSV();
            loadConfig();

            String logsPath = config.getProperty("logs.path");
            if (logsPath == null || logsPath.isEmpty()) {
                throw new RuntimeException("logs.path is not set in config.properties");
            }
            File logDir = new File(logsPath);
            if (!logDir.exists()) {
                logDir.mkdirs();
            }

            System.setProperty("logs.path", logsPath);
            logger.info("Starting application...");

            // Initialize Database
            dbHelper = new DBHelper();
            dbHelper.connect();

            // Initialize Chrome Driver with logging capabilities
            logger.info("Setting WebDriver paths");

            driver = initializeDriver(config);
            DriverContext.driver = driver;

            RemoteWebDriver remoteDriver = (RemoteWebDriver) driver;
            String sessionId = remoteDriver.getSessionId().toString();
            Timestamp startTime = new Timestamp(System.currentTimeMillis());
            DriverContext.SESSION_ID = sessionId;

            logger.info("Browser Session ID: " + sessionId);
            logger.info("Browser Session ID: " + sessionId);

            // Storing Session ID in database
            dbHelper.insertSessionInfo(sessionId, startTime);
            driver.manage().window().maximize();

            // globle wate time
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));

            // ========== HOME PAGE LOAD WITH SPEED MONITORING ==========
            currentStepIndex = Step.HOME_PAGE.ordinal();

            if (!flowFailed) {
                Timestamp stepStart = new Timestamp(System.currentTimeMillis());
                int httpCode = -1;
                try {
                    String appUrl = config.getProperty("app.url");
                    httpCode = getHttpStatusCode(appUrl);

                    // Initialize Network Speed Monitor
                    speedMonitor = new NetworkSpeedMonitor();
                    speedMonitor.initialize(driver);
                    logger.info("Network Speed Monitor initialized");

                    // Log geolocation
                    logGeolocation(DriverContext.SESSION_ID);
                    logger.info("Scaling geolocation logging");

                    Point location = driver.manage().window().getPosition();
                    logger.info(
                            "Browser launched at screen position: X = " + location.getX() + ", Y = " + location.getY());

                    // Start speed monitoring BEFORE navigation
                    speedMonitor.startMonitoring();

                    driver.get(appUrl);
                    // Thread.sleep(2000);

                    // Stop monitoring and get metrics
                    NetworkSpeedMonitor.NetworkMetrics metrics = speedMonitor.stopMonitoring();

                    // Capture browser errors
                    String browserErrors = captureBrowserErrors();

                    logger.info("Home page load successful");
                    logger.info("Status Code of application URL: {}", httpCode);

                    metrics.display();
                    saveSpeedMetrics("Home Page", appUrl, metrics);

                    Thread.sleep(5000);

                    // Log with browser errors if any
                    if (!browserErrors.isEmpty()) {
                        logger.warn("Browser errors detected on Home Page: {}", browserErrors);
                        logStep("Home Page", stepStart, "SUCCESS", "Page loaded with warnings: " + browserErrors,
                                httpCode);
                    } else {
                        logStep("Home Page", stepStart, "SUCCESS", "", httpCode);
                    }

                } 
                catch (Exception e) {
    flowFailed = true;
    errorLog = captureAllErrors(
            "Home Page",
            e);

    logger.error(errorLog, e);

    logStep(
            "Home Page",
            stepStart,
            "FAILURE",
            errorLog,
            httpCode);

    logRemainingStepsAsFailure(
            currentStepIndex + 1,
            "Skipped due to Home Page failure");
}

            
            }

            // globle wate time
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
            // ========== CLICK LOGIN BUTTON ==========
            currentStepIndex = Step.LOGIN.ordinal();

            if (!flowFailed) {
                Timestamp stepStart = new Timestamp(System.currentTimeMillis());
                int httpCode = -1;
                try {
                    String currentUrl = driver.getCurrentUrl();
                    httpCode = getHttpStatusCode(currentUrl);
                    // Email Production changes 
                    driver.findElement(By.xpath("//*[@id=\"email\"]")).sendKeys(config.getProperty("user.email"));
                    Thread.sleep(3000);
                    // lo
                    driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div/div/div[2]/form/button")).click();

                    String browserErrors = captureBrowserErrors();
                    // logger.info("Clicked on Login button");

                    if (!browserErrors.isEmpty()) {
                        logger.warn("Browser errors after clicking login: {}", browserErrors);
                        logStep("Login", stepStart, "SUCCESS", "Action completed with warnings: " + browserErrors,
                                httpCode);
                    } else {
                        logStep("Login", stepStart, "SUCCESS", "", httpCode);
                    }
                } catch (Exception e) {
    flowFailed = true;

    errorLog = captureAllErrors(
            "Login",
            e);

    logger.error(errorLog, e);

    logStep(
            "Login",
            stepStart,
            "FAILURE",
            errorLog,
            httpCode);

    logRemainingStepsAsFailure(
            currentStepIndex + 1,
            "Skipped due to Login failure");
}
            }

            // globle wate time
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
            // ==========================================================================================
            // ========== DASHBOARD ==========
            currentStepIndex = Step.DASHBOARD.ordinal();

            if (!flowFailed) {
                Timestamp stepStart = new Timestamp(System.currentTimeMillis());
                int httpCode = -1;

                try {
                    String currentUrl = driver.getCurrentUrl();
                    httpCode = getHttpStatusCode(currentUrl);
                    // Welcome .....name for 
                    driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/main/div/div/div/div[1]/div/p"));
                    Thread.sleep(2000);

                    // Capture browser/JS/network errors
                    String browserErrors = captureBrowserErrors();

                    if (!browserErrors.isEmpty()) {
                        logger.warn("Browser errors detected on Dashboard: {}", browserErrors);

                        logStep(
                                "Dashboard",
                                stepStart,
                                "FAILURE",
                                "Dashboard loaded with browser errors: " + browserErrors,
                                httpCode);

                        flowFailed = true;
                    } else {
                        logger.info("Dashboard loaded successfully");

                        logStep(
                                "Dashboard",
                                stepStart,
                                "SUCCESS",
                                "",
                                httpCode);
                    }

                } catch (Exception e) {

    flowFailed = true;

    errorLog = captureAllErrors(
            "Dashboard",
            e);

    logger.error(errorLog, e);

    logStep(
            "Dashboard",
            stepStart,
            "FAILURE",
            errorLog,
            httpCode);

    logRemainingStepsAsFailure(
            currentStepIndex + 1,
            "Skipped due to Dashboard failure");
}
            }

            // globle wate time
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));

            // ==========================================================================================
            // ========== TEMPLETE ==========

            currentStepIndex = Step.TEMPLETE.ordinal();

            if (!flowFailed) {

                Timestamp stepStart = new Timestamp(System.currentTimeMillis());
                int httpCode = -1;

                try {

                    String currentUrl = driver.getCurrentUrl();
                    httpCode = getHttpStatusCode(currentUrl);

                    logger.info("Navigating to Template page...");
                    System.out.println("Templete start.............. ");
                    // click on templete
                    driver.findElement(By.xpath("//*[@id=\"root\"]/div/aside/nav/div[3]/button/div[2]/svg")).click();

                    logger.info("Template menu clicked successfully");

                    Thread.sleep(5000);

                    // Optional validation for table container
                    WebElement actionColumn = driver.findElement(
                            By.xpath("//*[@id=\"root\"]/div/div/main/div/div[3]/div"));

                    if (actionColumn.isDisplayed()) {
                        logger.info("Template page loaded successfully");
                    }

                    String browserErrors = captureBrowserErrors();

                    if (!browserErrors.isEmpty()) {

                        logger.warn("Browser errors detected on Template page: {}",
                                browserErrors);

                        logStep(
                                "Template",
                                stepStart,
                                "FAILURE",
                                "Template page loaded with browser errors: "
                                        + browserErrors,
                                httpCode);

                        flowFailed = true;

                    } else {

                        logStep(
                                "Template",
                                stepStart,
                                "SUCCESS",
                                "",
                                httpCode);

                        logger.info("Template step completed successfully");
                    }

                } catch (Exception e) {

    flowFailed = true;

    errorLog = captureAllErrors(
            "Template",
            e);

    logger.error(errorLog, e);

    logStep(
            "Template",
            stepStart,
            "FAILURE",
            errorLog,
            httpCode);

    logRemainingStepsAsFailure(
            currentStepIndex + 1,
            "Skipped due to Template failure");
}
            }

            // globle wate time
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
            // ===========================================================================================

            // ========== DEPLOY JOURNEY ==========

            currentStepIndex = Step.DEPLOY_JOURNEY.ordinal();

            if (!flowFailed) {

                Timestamp stepStart = new Timestamp(System.currentTimeMillis());
                int httpCode = -1;

                try {

                    String currentUrl = driver.getCurrentUrl();
                    httpCode = getHttpStatusCode(currentUrl);

                    // Open Action Element
                    WebElement actionBtn = driver.findElement(
                            By.xpath("//*[@id=\"root\"]/div/div/main/div/div[3]/div/table/thead/tr/th[7]"));

                    ((JavascriptExecutor) driver)
                            .executeScript("arguments[0].scrollIntoView({block:'center'});",
                                    actionBtn);

                    Thread.sleep(2000);

                    actionBtn.click();
                    logger.info("Action element finded..");

                    // Click on three dots
                    // TODO: "radix-:r25:" / "radix-:r26:" / "radix-:r32:" below are Radix UI
                    // auto-generated ids, NOT stable across page loads/renders. These are a
                    // likely cause of intermittent failures in this step — replace with
                    // stable locators (data-testid, aria-label, button text) once confirmed
                    // against the live DOM.

// changes karna ha ...............................................................................................................

                    WebElement actionBtn1 = driver.findElement(
                            By.xpath("//*[@id=\"radix-:r26:\"]"));

                    ((JavascriptExecutor) driver)
                            .executeScript("arguments[0].scrollIntoView({block:'center'});",
                                    actionBtn);

                    Thread.sleep(2000);

                    actionBtn1.click();
                    logger.info("Click on three dots");

                    Thread.sleep(1000);

                    // Click Deploy Journey / Confirm Deploy
                    WebElement confirmDeploy = driver.findElement(
                            By.xpath("//*[@id=\"radix-:r27:\"]/div/button[1]"));

                    confirmDeploy.click();

                    logger.info("Deploy Journey confirmed");

                    // Verify deployment success message
                    WebElement successMsg = driver.findElement(
                            By.xpath("//*[@id=\"root\"]/div/div/main/div/div[1]/div/h1"));

                    if (successMsg.isDisplayed()) {
                        logger.info("Journey deployed successfully");
                    }

                    String browserErrors = captureBrowserErrors();

                    if (!browserErrors.isEmpty()) {

                        logger.warn("Browser errors detected during deployment: {}",
                                browserErrors);

                        logStep(
                                "Deploy Journey",
                                stepStart,
                                "FAILURE",
                                "Deployment completed with errors: " + browserErrors,
                                httpCode);

                        flowFailed = true;

                    } else {

                        logStep(
                                "Deploy Journey",
                                stepStart,
                                "SUCCESS",
                                "",
                                httpCode);

                        logger.info("Deploy Journey completed successfully");
                    }

                } catch (Exception e) {

    flowFailed = true;

    errorLog = captureAllErrors(
            "Deploy Journey",
            e);

    logger.error(errorLog, e);

    logStep(
            "Deploy Journey",
            stepStart,
            "FAILURE",
            errorLog,
            httpCode);

    logRemainingStepsAsFailure(
            currentStepIndex + 1,
            "Skipped due to Deploy Journey failure");
}
            }

            // globle wate time
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
            // ==========================================================================================
            // ========== INSTANCE VIEW ==========

            currentStepIndex = Step.INSTANCE_VIEW.ordinal();

            if (!flowFailed) {

                Timestamp stepStart = new Timestamp(System.currentTimeMillis());
                int httpCode = -1;

                try {

                    String currentUrl = driver.getCurrentUrl();
                    httpCode = getHttpStatusCode(currentUrl);

                    logger.info("Opening Instance View...");

                    // Click Instance menu button
                    WebElement instanceMenu = driver.findElement(
                            By.xpath("//*[@id=\"root\"]/div/div/main/div/div[2]/div[2]/button[1]"));

                    ((JavascriptExecutor) driver)
                            .executeScript(
                                    "arguments[0].scrollIntoView({block:'center'});",
                                    instanceMenu);

                    Thread.sleep(2000);

                    // instanceMenu.click();

                    logger.info("Instance View success");

                    Thread.sleep(5000);

                    // Click specific Instance row
                    WebElement instanceRow = driver.findElement(
                            By.xpath("//*[@id=\"root\"]/div/div/main/div/div[3]/div/div/table/tbody/tr[1]"));

                    ((JavascriptExecutor) driver)
                            .executeScript(
                                    "arguments[0].scrollIntoView({block:'center'});",
                                    instanceRow);

                    Thread.sleep(2000);

                    instanceRow.click();

                    logger.info("Selected first instance");

                    Thread.sleep(5000);

                    // Validation
                    WebElement instanceDetails = driver.findElement(
                            By.xpath("//*[@id=\"root\"]/div/div/main/div/div[3]/div/div/table/thead/tr/th[12]"));

                    if (instanceDetails.isDisplayed()) {
                        logger.info("Instance View loaded successfully");
                    }

                    String browserErrors = captureBrowserErrors();

                    if (!browserErrors.isEmpty()) {

                        logger.warn(
                                "Browser errors detected on Instance View: {}",
                                browserErrors);

                        logStep(
                                "Instance View",
                                stepStart,
                                "FAILURE",
                                "Instance View loaded with browser errors: "
                                        + browserErrors,
                                httpCode);

                        flowFailed = true;

                    } else {

                        logStep(
                                "Instance View",
                                stepStart,
                                "SUCCESS",
                                "",
                                httpCode);

                        logger.info(
                                "Instance View completed successfully");
                    }

                } catch (Exception e) {

    flowFailed = true;

    errorLog = captureAllErrors(
            "Instance View",
            e);

    logger.error(errorLog, e);

    logStep(
            "Instance View",
            stepStart,
            "FAILURE",
            errorLog,
            httpCode);

    logRemainingStepsAsFailure(
            currentStepIndex + 1,
            "Skipped due to Instance View failure");
}
            }

            // globle wate time
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
            // ==========================================================================================
            // ========== CONSOLE ==========

            currentStepIndex = Step.CONSOLE.ordinal();

            if (!flowFailed) {

                Timestamp stepStart = new Timestamp(System.currentTimeMillis());
                int httpCode = -1;

                try {

                    String currentUrl = driver.getCurrentUrl();
                    httpCode = getHttpStatusCode(currentUrl);

                    logger.info("Opening Console...");

                    // Click Three Dots / Action Menu
                    // TODO: same fragile Radix auto-generated id issue as noted in the
                    // Deploy Journey step above.
                    WebElement actionBtn = driver.findElement(
                            By.xpath("//*[@id=\"radix-:r6c:\"]"));

                    ((JavascriptExecutor) driver)
                            .executeScript(
                                    "arguments[0].scrollIntoView({block:'center'});",
                                    actionBtn);

                    Thread.sleep(2000);

                    actionBtn.click();

                    logger.info("Clicked Action Menu");

                    Thread.sleep(80000);

                    // Click Console Button
                    WebElement consoleBtn = driver.findElement(
                            By.xpath("//*[@id=\"radix-:r6d:\"]/div/button[5]"));

                    ((JavascriptExecutor) driver)
                            .executeScript(
                                    "arguments[0].scrollIntoView({block:'center'});",
                                    consoleBtn);

                    Thread.sleep(1000);

                    consoleBtn.click();

                    logger.info("Console opened successfully");

                    Thread.sleep(10000);

                    // Validate Console Canvas Loaded
                    WebElement consoleCanvas = driver.findElement(
                            By.xpath("//*[@id=\"novnc-container\"]/div/canvas"));

                    if (consoleCanvas.isDisplayed()) {
                        logger.info("Console loaded successfully");
                    } else {
                        throw new Exception("Console canvas not visible");
                    }



                    String browserErrors = captureBrowserErrors();
if (browserErrors.contains("[SEVERE]")) {

    logStep(
        "Console",
        stepStart,
        "FAILURE",
        browserErrors,
        httpCode);

    flowFailed = true;

} else {

    logger.warn(browserErrors);

    logStep(
        "Console",
        stepStart,
        "SUCCESS",
        "Warnings found: " + browserErrors,
        httpCode);
} 

} catch (Exception e) {

    flowFailed = true;

    errorLog = captureAllErrors(
            "Console",
            e);

    logger.error(errorLog, e);

    logStep(
            "Console",
            stepStart,
            "FAILURE",
            errorLog,
            httpCode);

    logRemainingStepsAsFailure(
            currentStepIndex + 1,
            "Skipped due to Console failure");
}
            }


            if (!flowFailed) {
                logger.info("Execution completed successfully.");
            } else {
                logger.warn("Execution completed with failures.");
                status = "FAILURE";
            }

        } catch (Exception e) {
            status = "FAILURE";
            errorLog = "Unexpected failure: " + truncateError(e.getMessage());
            logger.error("Unexpected error during execution", e);
        } finally {
            overallEndTime = new Timestamp(System.currentTimeMillis());
            responseTime = overallEndTime.getTime() - overallStartTime.getTime();

            try {
                logger.info("Final session status: {}", status);
                logger.info("Total execution time: {} ms", responseTime);

                if (dbHelper != null && DriverContext.SESSION_ID != null) {
                    dbHelper.finalizeSession(DriverContext.SESSION_ID, status);
                }

            } catch (Exception e) {
                logger.error("Failed to finalize session", e);
            }

            // Cleanup
            try {
                if (speedMonitor != null)
                    speedMonitor.close();
                if (driver != null)
                    driver.quit();
                if (dbHelper != null)
                    dbHelper.close();
            } catch (Exception ignored) {
            }
        }
    }

  
    // capture page error

    private static void logPageErrors(
            String stepName) {

        try {

            String browserErrors = captureBrowserErrors();

            if (!browserErrors.isEmpty()) {

                writeErrorToCSV(

                        stepName,

                        "PAGE_ERROR",

                        "Browser/Page issue detected",

                        browserErrors,

                        "");
            }

        } catch (Exception e) {

            logger.error(
                    "Page error capture failed",
                    e);
        }
    }

    /**
     * Capture browser console errors and network errors
     */
    private static String captureBrowserErrors() {
        StringBuilder errors = new StringBuilder();
        try {
            // Capture browser console logs (JavaScript errors, warnings, etc.)
            LogEntries logEntries = driver.manage().logs().get(LogType.BROWSER);
            List<String> errorList = new ArrayList<>();

            for (LogEntry entry : logEntries) {
                Level level = entry.getLevel();
                // Capture SEVERE and WARNING level entries only.
                // (INFO was previously included, which flagged normal console
                // logging as "browser errors" on nearly every step.)
                boolean hasSevereError = false;
                if (level == Level.SEVERE) {
                    hasSevereError = true;
                    String errorMsg = String.format("[%s] %s", level.getName(), entry.getMessage());
                    errorList.add(errorMsg);
                    
                }
            }

            if (!errorList.isEmpty()) {
                errors.append("Browser Console Errors: ");
                errors.append(String.join(" | ", errorList));
            }

            // You can also capture performance logs for network errors
            try {
                LogEntries perfLogs = driver.manage().logs().get(LogType.PERFORMANCE);
                List<String> networkErrors = new ArrayList<>();

                for (LogEntry entry : perfLogs) {
                    String message = entry.getMessage();
                    // Look for failed network requests
                    if (message.contains("\"method\":\"Network.responseReceived\"") &&
                            (message.contains("\"status\":4") || message.contains("\"status\":5"))) {
                        networkErrors.add("Network error detected in performance logs");
                    }
                }

                if (!networkErrors.isEmpty() && errors.length() > 0) {
                    errors.append(" | ");
                }
                if (!networkErrors.isEmpty()) {
                    errors.append("Network Issues: ");
                    errors.append(String.join(" | ", networkErrors));
                }
            } catch (Exception e) {
                // Performance logs might not be available
                logger.debug("Could not capture performance logs: {}", e.getMessage());
            }

        } catch (Exception e) {
            logger.warn("Failed to capture browser errors: {}", e.getMessage());
        }

        return errors.toString();
    }

    /**
     * Build comprehensive error message including exception and browser errors
     */
    private static String buildErrorMessage(String context, Exception exception, String browserErrors) {
        StringBuilder errorMsg = new StringBuilder();
        errorMsg.append(context).append(": ");

        // Add exception details
        if (exception != null) {
            errorMsg.append("Exception: ").append(exception.getClass().getSimpleName()).append(" - ");

            // Clean the exception message - remove Selenium documentation links and build
            // info
            String cleanMessage = cleanExceptionMessage(exception.getMessage());
            errorMsg.append(truncateError(cleanMessage));

            // Add root cause if available
            Throwable cause = exception.getCause();
            if (cause != null) {
                String cleanCauseMessage = cleanExceptionMessage(cause.getMessage());
                errorMsg.append(" | Root Cause: ").append(cause.getClass().getSimpleName());
                errorMsg.append(" - ").append(truncateError(cleanCauseMessage));
            }
        }

        // Add browser errors if any
        if (browserErrors != null && !browserErrors.isEmpty()) {
            errorMsg.append(" | ").append(browserErrors);
        }

        return errorMsg.toString();
    }

    /**
     * Clean exception message by removing Selenium documentation links and build
     * info
     */
    private static String cleanExceptionMessage(String message) {
        if (message == null || message.isEmpty()) {
            return "";
        }

        // Split by newline and take only the first meaningful line
        String[] lines = message.split("\\r?\\n");
        StringBuilder cleanMsg = new StringBuilder();

        for (String line : lines) {
            line = line.trim();

            // Skip lines containing documentation links, build info, system info, driver
            // info
            if (line.contains("For documentation on this error") ||
                    line.contains("https://www.selenium.dev/") ||
                    line.contains("Build info:") ||
                    line.contains("System info:") ||
                    line.contains("Driver info:") ||
                    line.contains("Command duration") ||
                    line.contains("Capabilities") ||
                    line.contains("Session ID:") ||
                    line.isEmpty()) {
                continue;
            }

            // Add meaningful lines
            if (cleanMsg.length() > 0) {
                cleanMsg.append(" ");
            }
            cleanMsg.append(line);
        }

        return cleanMsg.toString();
    }

    /**
     * Log all remaining steps as FAILURE when a previous step fails
     */
    private static void logRemainingStepsAsFailure(int startIndex, String reason) {
        for (int i = startIndex; i < STEP_FLOW.length; i++) {
            Step step = STEP_FLOW[i];
            logStep(
                    step.name().replace("_", " "),
                    new Timestamp(System.currentTimeMillis()),
                    "FAILURE",
                    reason,
                    -1);
            logger.warn("Step {} marked FAILURE (not executed)", step);
        }
    }

    /**
     * Save network speed metrics to database
     */
    private static void saveSpeedMetrics(String testName, String url, NetworkSpeedMonitor.NetworkMetrics metrics) {
        try {
            dbHelper.insertNetworkSpeed(DriverContext.SESSION_ID,
                    testName,
                    url,
                    metrics.downloadSpeedMbps,
                    metrics.uploadSpeedMbps,
                    metrics.downloadSpeedMBps,
                    metrics.uploadSpeedMBps,
                    metrics.totalBytesReceived,
                    metrics.totalBytesSent,
                    metrics.totalRequests,
                    metrics.durationSeconds,
                    metrics.avgRequestTimeMs,
                    metrics.pageLoadTimeMs);
            logger.info("Network speed metrics saved for: {}", testName);
        } catch (Exception e) {
            logger.error("Failed to save network speed metrics for {}: {}", testName, e.getMessage(), e);
        }
    }

    private static void loadConfig() throws IOException {
        config = new Properties();
        FileInputStream fis = new FileInputStream("conf/config.properties");
        config.load(fis);
    }


    // this script actually runs: Home -> Login -> Dashboard -> Template ->
    // Deploy Journey -> Instance View -> Console -> Logout). Restore them
    // from version control if you still need that flow elsewhere.

    private static void logStep(String stepName, Timestamp startTime, String status, String errorLog,
            int responseCode) {
        Timestamp endTime = new Timestamp(System.currentTimeMillis());
        long responseTime = endTime.getTime() - startTime.getTime();

        if ("FAILURE".equalsIgnoreCase(status)) {
            captureSnapshot(stepName);
        }

        try {
            dbHelper.insertLog(DriverContext.SESSION_ID, stepName, startTime, endTime, responseTime, status, errorLog,
                    responseCode);
        } catch (Exception e) {
            logger.error("Failed to insert log for step '" + stepName + "': " + truncateError(e.getMessage()), e);
        }
    }

    private static String truncateError(String message) {
        if (message == null)
            return "";
        return message.length() > 500 ? message.substring(0, 500) + "..." : message;
    }

    // new
    private static String captureSnapshot(String stepName) {

        try {

            String snapshotDirPath = "snapshots";

            File snapshotDir = new File(snapshotDirPath);

            if (!snapshotDir.exists()) {
                snapshotDir.mkdirs();
            }

            String timestamp = String.valueOf(System.currentTimeMillis());

            String fileName = stepName.replaceAll("[^a-zA-Z0-9_-]", "_")
                    + "_" + timestamp + ".png";

            File destFile = new File(snapshotDirPath
                    + File.separator
                    + fileName);

            File screenshot = ((TakesScreenshot) driver)
                    .getScreenshotAs(OutputType.FILE);

            FileHandler.copy(screenshot, destFile);

            logger.info(
                    "Snapshot saved at {}",
                    destFile.getAbsolutePath());

            return destFile.getAbsolutePath();

        } catch (Exception e) {

            logger.error(
                    "Failed to capture screenshot",
                    e);

            return "";
        }
    }

    private static synchronized void writeErrorToCSV(
            String stepName,
            String errorType,
            String errorMessage,
            String browserErrors,
            String screenshotPath) {

        try {

            String url = "";

            try {
                url = driver.getCurrentUrl();
            } catch (Exception ignored) {
            }

            String sessionId = DriverContext.SESSION_ID;

            PrintWriter pw = new PrintWriter(
                    new FileWriter(
                            CSV_FILE,
                            true));

            pw.printf(
                    "\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\"%n",

                    new Timestamp(
                            System.currentTimeMillis()),

                    sessionId,

                    stepName,

                    errorType,

                    errorMessage
                            .replace(",", ";"),

                    url,

                    browserErrors
                            .replace(",", ";"),

                    screenshotPath);

            pw.close();

        } catch (Exception ex) {

            logger.error(
                    "CSV writing failed",
                    ex);
        }
    }

    private static synchronized void saveErrorToCSV(
            String stepName,
            Exception exception,
            String browserErrors,
            String screenshotPath) {

        try {

            // Use the same CSV_FILE constant as writeErrorToCSV()/initializeCSV()
            // instead of a separate hardcoded "ErrorLogs.csv" in the working dir.
            File file = new File(CSV_FILE);

            File folder = new File(CSV_FOLDER);
            if (!folder.exists()) {
                folder.mkdirs();
            }

            boolean fileExists = file.exists();

            logger.info("CSV File Path : {}", file.getAbsolutePath());

            FileWriter fw = new FileWriter(file, true);

            PrintWriter pw = new PrintWriter(fw);

            if (!fileExists) {

                pw.println(
                        "Timestamp," +
                                "SessionID," +
                                "StepName," +
                                "ExceptionType," +
                                "ErrorMessage," +
                                "URL," +
                                "BrowserErrors," +
                                "ScreenshotPath");
            }

            String timestamp = new Timestamp(
                    System.currentTimeMillis())
                    .toString();

            String sessionId = DriverContext.SESSION_ID != null
                    ? DriverContext.SESSION_ID
                    : "NA";

            String currentUrl = "NA";

            try {
                currentUrl = driver.getCurrentUrl();
            } catch (Exception ignored) {
            }

            String exceptionType = exception != null
                    ? exception.getClass().getSimpleName()
                    : "BrowserError";

            String errorMessage = exception != null
                    ? cleanExceptionMessage(
                            exception.getMessage())
                    : browserErrors;

            if (errorMessage == null) {
                errorMessage = "";
            }

            errorMessage = errorMessage.replace(",", ";");

            browserErrors = browserErrors.replace(",", ";");

            pw.printf(
                    "\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\"%n",
                    timestamp,
                    sessionId,
                    stepName,
                    exceptionType,
                    errorMessage,
                    currentUrl,
                    browserErrors,
                    screenshotPath);

            pw.flush();
            logger.info("Error written successfully to CSV");
            pw.close();

            logger.info("Error saved to CSV");

        } catch (Exception e) {

            logger.error(
                    "Failed to save error CSV",
                    e);
        }
    }

    // universal error cpture

    private static String captureAllErrors(
            String stepName,
            Exception exception) {

        logger.info("captureAllErrors() called for step : {}", stepName);   

        StringBuilder errorLog = new StringBuilder();

        try {

            String browserErrors = captureBrowserErrors();

            String screenshotPath = captureSnapshot(stepName);

            if (exception != null) {

                errorLog.append(
                        "Exception Type: ")
                        .append(
                                exception.getClass()
                                        .getSimpleName());

                errorLog.append(
                        " | Message: ")
                        .append(
                                cleanExceptionMessage(
                                        exception.getMessage()));

                StackTraceElement[] stack = exception.getStackTrace();

                if (stack.length > 0) {

                    errorLog.append(
                            " | Class: ")
                            .append(stack[0]
                                    .getClassName());

                    errorLog.append(
                            " | Method: ")
                            .append(stack[0]
                                    .getMethodName());

                    errorLog.append(
                            " | Line: ")
                            .append(stack[0]
                                    .getLineNumber());
                }
            }

            if (!browserErrors.isEmpty()) {

                errorLog.append(
                        " | BrowserErrors: ")
                        .append(browserErrors);
            }

            saveErrorToCSV(
                    stepName,
                    exception,
                    browserErrors,
                    screenshotPath);

        } catch (Exception e) {

            logger.error(
                    "Error capture failed",
                    e);
        }

        return errorLog.toString();
    }

    private static void logBrowserErrorsToCSV(
            String stepName) {

        try {

            String browserErrors = captureBrowserErrors();

            if (!browserErrors.isEmpty()) {

                saveErrorToCSV(
                        stepName,
                        null,
                        browserErrors,
                        "");
            }

        } catch (Exception e) {

            logger.error(
                    "Browser log collection failed",
                    e);
        }
    }

    private static void logGeolocation(String sessionId) {
        try {
            String apiURL = "http://ip-api.com/json";
            HttpURLConnection connection = (HttpURLConnection) new URL(apiURL).openConnection();
            connection.setRequestMethod("GET");

            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder response = new StringBuilder();
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            JSONObject geoData = new JSONObject(response.toString());

            logger.info("Geolocation Info:");
            String ip_address = geoData.getString("query");
            logger.info("IP Address: " + ip_address);
            String city = geoData.getString("city");
            logger.info("City: " + city);
            String region = geoData.getString("regionName");
            logger.info("Region: " + region);
            String country = geoData.getString("country");
            logger.info("Country: " + country);
            String isp = geoData.getString("isp");
            logger.info("ISP: " + isp);
            String timezone = geoData.getString("timezone");
            logger.info("Timezone: " + timezone);
            double longitude = geoData.getDouble("lon");
            logger.info("Longitude: " + longitude);
            double latitude = geoData.getDouble("lat");
            logger.info("Latitude: " + latitude);
            String browser = config.getProperty("driver.name");
            logger.info("Browser: " + browser);

            dbHelper.insertGeoLocation(sessionId, ip_address, city, region, country, isp, timezone, latitude, longitude,
                    browser);

        } catch (Exception e) {
            logger.warn("Failed to fetch geolocation: " + e.getMessage());
        }
    }

    private static int getHttpStatusCode(String urlString) {
        try {
            URL url = new URL(urlString);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(5000);
            connection.connect();
            int responseCode = connection.getResponseCode();
            logger.debug("HTTP Status Code for {}: {}", urlString, responseCode);
            return responseCode;
        } catch (IOException e) {
            logger.warn("Failed to get HTTP status for URL: " + urlString + " - " + e.getMessage());
            return -1;
        }
    }

    private static WebDriver initializeDriver(Properties config) {

        String browser = config.getProperty("driver.name").trim();

        LoggingPreferences logPrefs = new LoggingPreferences();
        logPrefs.enable(LogType.BROWSER, Level.ALL);
        logPrefs.enable(LogType.PERFORMANCE, Level.ALL);

        switch (browser.toLowerCase()) {

            case "chrome":
                System.setProperty("webdriver.chrome.driver", config.getProperty("driver.path"));

                ChromeOptions chromeOptions = new ChromeOptions();
                chromeOptions.setCapability("goog:loggingPrefs", logPrefs);

                return new ChromeDriver(chromeOptions);

            case "edge":
                System.setProperty("webdriver.edge.driver", config.getProperty("driver.path"));

                EdgeOptions edgeOptions = new EdgeOptions();
                edgeOptions.setCapability("goog:loggingPrefs", logPrefs);

                return new EdgeDriver(edgeOptions);

            default:
                throw new IllegalArgumentException("Unsupported browser: " + browser);
        }
    }

}