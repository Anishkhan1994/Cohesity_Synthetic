package com.culeportal;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Files;
import java.util.UUID;

import org.json.JSONObject;

public class CaptchaValidation {

    public static String sendImageToOCRApi(String imagePath, String apiUrl) {
        try {
            File uploadFile = new File(imagePath);

            URL url = new URL(apiUrl);
            HttpURLConnection httpConn = (HttpURLConnection) url.openConnection();
            httpConn.setUseCaches(false);
            httpConn.setDoOutput(true);
            httpConn.setDoInput(true);
            httpConn.setRequestMethod("POST");

            // Generate boundary for multipart form data
            String boundary = "----" + UUID.randomUUID().toString();
            httpConn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);

            OutputStream outputStream = httpConn.getOutputStream();
            PrintWriter writer = new PrintWriter(new OutputStreamWriter(outputStream, "UTF-8"), true);

            // Add form field
            writer.append("--" + boundary).append("\r\n");
            writer.append("Content-Disposition: form-data; name=\"image\"; filename=\"" + uploadFile.getName() + "\"").append("\r\n");
            writer.append("Content-Type: image/png").append("\r\n");
            writer.append("\r\n").flush();

            // Add file content
            Files.copy(uploadFile.toPath(), outputStream);
            outputStream.flush();

            // End boundary
            writer.append("\r\n").flush();
            writer.append("--" + boundary + "--").append("\r\n").flush();
            writer.close();

            int status = httpConn.getResponseCode();
            InputStream responseStream = (status == HttpURLConnection.HTTP_OK)
                    ? httpConn.getInputStream()
                    : httpConn.getErrorStream();

            BufferedReader reader = new BufferedReader(new InputStreamReader(responseStream));
            StringBuilder responseStrBuilder = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                responseStrBuilder.append(line);
            }
            reader.close();
            httpConn.disconnect();

            System.out.println("API Response: " + responseStrBuilder.toString()); // Debug output

            JSONObject jsonResponse = new JSONObject(responseStrBuilder.toString());
            if (jsonResponse.getBoolean("success")) {
                return jsonResponse.getString("detectedText");
            } else {
                return "Failed to detect text";
            }

        } catch (Exception e) {
            e.printStackTrace();
            return "Error occurred: " + e.getMessage();
        }
    }
}
