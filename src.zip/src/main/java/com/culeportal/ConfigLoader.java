package com.culeportal;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ConfigLoader {
    private static Properties properties = new Properties();

    static {
        try {
            FileInputStream fis = new FileInputStream("conf/config.properties");
            properties.load(fis);
            fis.close();
        } catch (IOException e) {
            System.err.println("❌ Failed to load config.properties file.");
            e.printStackTrace();
        }
    }

    public static String get(String key) {
        return properties.getProperty(key);
    }
}
