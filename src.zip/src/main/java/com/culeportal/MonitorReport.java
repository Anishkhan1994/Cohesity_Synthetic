package com.culeportal;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;

import com.aventstack.extentreports.*;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class MonitorReport {

    public static void main(String[] args) {

        ExtentSparkReporter spark =
            new ExtentSparkReporter("D:\\RND\\Synthetic Monitoring\\onlinebanking\\src\\main\\java\\com\\onlinebanking\\Report\\monitor-report.html");

        ExtentReports extent = new ExtentReports();
        extent.attachReporter(spark);

        ExtentTest test =
            extent.createTest("Synthetic Monitoring Test");

        System.setProperty("webdriver.edge.driver", "D:\\RND\\Synthetic Monitoring\\onlinebanking\\driver\\msedgedriver.exe");
        EdgeOptions options = new EdgeOptions();
        EdgeDriver driver = new EdgeDriver(options);

        try {

            long start = System.currentTimeMillis();

            driver.get("https://www.iba-banksewa.in/sewa/service-innerpage/MTA%3D");

            String title = driver.getTitle();

            long loadTime =
                System.currentTimeMillis() - start;

            test.info("Page Title: " + title);

            test.info("Load Time: " + loadTime + " ms");

            String status = driver.findElement(
                By.xpath("/html/body/app-root/app-before-login-header/mat-sidenav-container/mat-sidenav-content/mat-sidenav-container/mat-sidenav-content/div/app-sevices-inner-page/div[2]/div/div/div/div[2]/div[1]/div/ul/li[1]/span")
            ).getText();

            test.info("System Status: " + status);

            if(status.equalsIgnoreCase("Healthy")) {
                test.pass("Application is healthy");
            } else {
                test.fail("Application unhealthy");
            }

        } catch(Exception e) {

            test.fail(e);

        } finally {

            driver.quit();

            extent.flush();
        }
    }
}